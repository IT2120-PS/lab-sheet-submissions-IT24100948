setwd("C:\\Users\\IT24100948\\Desktop\\IT24100948")
getwd()
#Q1
branch_data<-read.csv("Exercise.txt",header = TRUE)

#Q2
str(branch_data)

#Q3
boxplot(branch_data$Sales_X1,
        main = "Boxplote of sales_x1",
        outline = TRUE,
        col="green",
        outpch =8,
        horizontal = TRUE)
#Q4
fivenum(branch_data$Advertising_X2)

#Q5
find_outliers<-function(x){
  q1 <- quantile(x,0.25)
  q3<- quantile(x,0.75)
  iqr <- q3-q1
  lower <- q1 -1.5*iqr
  upper <- q3+1.5*iqr
  outerliers<- x[x< lower|x > upper]
  return(outerliers)
}

find_outliers(branch_data$Years_X3)
integer(0)