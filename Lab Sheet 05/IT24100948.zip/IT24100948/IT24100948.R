setwd("C:\\Users\\IT24100948\\Desktop\\IT24100948")
getwd()

#Q1
delivery_data<- read.table("Exercise - Lab 05.txt",header = TRUE , sep = ",")

#Q2
names(Delivery_Times)<-c("Time")
histogram <- hist(main ="Histogram for Delivery Time", Delivery_Times$Time, breaks = seq(20,70, length=10),right =FALSE)

#Q4
breaks <- round(histogram$breaks)
freq   <- histogram$counts
mids   <- histogram$mids

classes <- c()
for(i in 1:(length(breaks)-1)){
  classes[i]<-paste0("[",breaks[i],",",breaks[i+1],")")
}

cum.freq <- cumsum(freq)
new <- c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i] = cum.freq[i-1]
  }
}
plot(breaks,new,type = 'l',main="cumalative frequrncy polygon for delivery times",xlab = "Delivery Times",
     ylab ="Cumulative Frequency",ylim = c(0,max(cum.freq)))

